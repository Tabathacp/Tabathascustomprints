import React from "react";
import { motion } from "framer-motion";
import { ShoppingBag, Sparkles, Phone, Mail, Instagram, Facebook, Star, Shirt, CupSoda, Scissors, Gift } from "lucide-react";

const categories = [
  { icon: <Shirt className="w-6 h-6" />, title: "Tees & Apparel", blurb: "Bella+Canvas, Next Level, Gildan—custom fits for every body." },
  { icon: <CupSoda className="w-6 h-6" />, title: "Tumblers", blurb: "Sublimation tumblers with vibrant, durable prints (20oz & 30oz)." },
  { icon: <Scissors className="w-6 h-6" />, title: "Decals", blurb: "Car/window decals, dishwasher-safe labels, and more." },
  { icon: <Gift className="w-6 h-6" />, title: "Gifts & Ornaments", blurb: "Personalized ornaments, keychains, and keepsakes." },
];

const products = [
  { title: "Comfort Tee — Custom", price: "From $22", img: "https://placehold.co/600x400?text=Tee+Mockup", sku: "tee-custom", checkoutLink: "https://square.link/u/your-tee-link" },
  { title: "20oz Tumbler — Custom", price: "From $25", img: "https://placehold.co/600x400?text=20oz+Tumbler", sku: "tumbler-20oz", checkoutLink: "https://square.link/u/your-20oz-link" },
  { title: "Car Decal — Custom", price: "From $8", img: "https://placehold.co/600x400?text=Decal", sku: "decal-custom", checkoutLink: "https://square.link/u/your-decal-link" },
  { title: "Porcelain Ornament — Custom", price: "From $15", img: "https://placehold.co/600x400?text=Ornament", sku: "ornament-porcelain", checkoutLink: "https://square.link/u/your-ornament-link" },
];

const reviews = [
  { name: "Amanda R.", text: "Exactly what I pictured. Colors pop and the fit is perfect.", stars: 5 },
  { name: "Devon P.", text: "She nailed a memorial tumbler for my sister—thank you.", stars: 5 },
  { name: "Kelly W.", text: "Fast, friendly, and super high-quality prints.", stars: 5 },
];

const Section = ({ id, title, children }) => (
  <section id={id} className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
    <h2 className="text-3xl sm:text-4xl font-semibold tracking-tight mb-8">{title}</h2>
    {children}
  </section>
);

export default function App() {
  const [cart, setCart] = React.useState([]);
  const addToCart = (item) => setCart((c) => [...c, item]);
  const cartCount = cart.length;
  return (
    <div className="min-h-screen bg-white text-gray-900">
      {/* Top bar */}
      <header className="sticky top-0 z-40 backdrop-blur bg-white/80 border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <a href="#home" className="flex items-center gap-2 font-semibold">
            <Sparkles className="w-5 h-5" />
            <span>Tabatha's Custom Prints</span>
          </a>
          <nav className="hidden md:flex items-center gap-6 text-sm">
            <a href="#shop" className="hover:text-gray-700">Shop</a>
            <a href="#gallery" className="hover:text-gray-700">Gallery</a>
            <a href="#faq" className="hover:text-gray-700">FAQ</a>
            <a href="#contact" className="hover:text-gray-700">Contact</a>
            <a href="#custom" className="inline-flex items-center gap-2 px-3 py-2 rounded-xl bg-gray-900 text-white hover:bg-gray-800">
              <Sparkles className="w-4 h-4" /> Custom Order
            </a>
            <a href="#shop" className="relative inline-flex items-center gap-2 px-3 py-2 rounded-xl border border-gray-300 hover:border-gray-400">
              <ShoppingBag className="w-4 h-4" />
              <span>Cart</span>
              <span className="ml-1 inline-flex items-center justify-center text-[10px] w-5 h-5 rounded-full border border-gray-300">{cartCount}</span>
            </a>
          </nav>
        </div>
      </header>

      {/* Hero */}
      <section id="home" className="relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-gray-100 via-white to-white" />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-semibold leading-tight tracking-tight">
                Custom tees, tumblers & gifts
                <span className="block text-gray-500 text-2xl sm:text-3xl mt-3">Handmade with care in Ohio</span>
              </h1>
              <p className="mt-6 text-lg text-gray-600 max-w-xl">
                Personal designs, memorial pieces, team gear, and event orders. You imagine it—we make it.
              </p>
              <div className="mt-8 flex flex-wrap gap-4">
                <a href="#shop" className="inline-flex items-center gap-2 px-5 py-3 rounded-2xl bg-gray-900 text-white hover:bg-gray-800">
                  <ShoppingBag className="w-5 h-5" /> Shop featured
                </a>
                <a href="#custom" className="inline-flex items-center gap-2 px-5 py-3 rounded-2xl border border-gray-300 hover:border-gray-400">
                  <Sparkles className="w-5 h-5" /> Start a custom order
                </a>
              </div>
            </motion.div>
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.15 }}>
              <div className="aspect-[4/3] rounded-3xl border border-gray-200 bg-white shadow-sm overflow-hidden">
                <img src="https://placehold.co/1200x900?text=Your+Product+Photo+Here" alt="Featured products" className="w-full h-full object-cover" />
              </div>
              <p className="text-sm text-gray-500 mt-3">Swap this image for a real photo of your work.</p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Categories */}
      <Section id="categories" title="What we make">
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {categories.map((c, i) => (
            <motion.div key={i} initial={{ opacity: 0, y: 10 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.4, delay: i * 0.05 }} className="p-6 rounded-2xl border border-gray-200 bg-white shadow-sm">
              <div className="flex items-center gap-3 mb-3">
                <div className="p-2 rounded-xl bg-gray-100">{c.icon}</div>
                <h3 className="font-medium">{c.title}</h3>
              </div>
              <p className="text-gray-600 text-sm">{c.blurb}</p>
            </motion.div>
          ))}
        </div>
      </Section>

      {/* Shop / Featured */}
      <Section id="shop" title="Featured picks">
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {products.map((p, i) => (
            <motion.article key={i} initial={{ opacity: 0, y: 10 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.4, delay: i * 0.05 }} className="rounded-2xl border border-gray-200 bg-white shadow-sm overflow-hidden">
              <div className="aspect-[4/3]">
                <img src={p.img} alt={p.title} className="w-full h-full object-cover" />
              </div>
              <div className="p-4">
                <h3 className="font-medium">{p.title}</h3>
                <p className="text-sm text-gray-600">{p.price}</p>
                <div className="mt-4 flex gap-3">
                  <button onClick={() => addToCart(p)} className="text-sm inline-flex px-3 py-2 rounded-xl bg-gray-900 text-white hover:bg-gray-800">Add to cart</button>
                  {p.checkoutLink ? (
                    <a href={p.checkoutLink} target="_blank" rel="noreferrer" className="text-sm inline-flex px-3 py-2 rounded-xl border border-gray-300 hover:border-gray-400">Checkout (Square)</a>
                  ) : (
                    <a href={`mailto:tabathascustomprints@gmail.com?subject=Order: ${encodeURIComponent(p.title)}&body=Hi Tab, I'd like to order the ${encodeURIComponent(p.title)}. Quantity: 1.`} className="text-sm inline-flex px-3 py-2 rounded-xl border border-gray-300 hover:border-gray-400">Checkout (Square)</a>
                  )}
                </div>
              </div>
            </motion.article>
          ))}
        </div>
      </Section>

      {/* Gallery */}
      <Section id="gallery" title="Recent work">
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="aspect-[4/3] rounded-2xl overflow-hidden border border-gray-200 bg-white">
              <img src={`https://placehold.co/1200x900?text=Gallery+${i + 1}`} alt={`Gallery ${i + 1}`} className="w-full h-full object-cover" />
            </div>
          ))}
        </div>
      </Section>

      {/* Reviews */}
      <Section id="reviews" title="Kind words">
        <div className="grid lg:grid-cols-3 gap-6">
          {reviews.map((r, i) => (
            <div key={i} className="p-6 rounded-2xl border border-gray-200 bg-white shadow-sm">
              <div className="flex items-center gap-2 text-amber-500 mb-2">
                {Array.from({ length: r.stars }).map((_, s) => <Star key={s} className="w-4 h-4 fill-current" />)}
              </div>
              <p className="text-gray-700">“{r.text}”</p>
              <p className="mt-3 text-sm text-gray-500">— {r.name}</p>
            </div>
          ))}
        </div>
      </Section>

      {/* Custom Order CTA */}
      <Section id="custom" title="Start a custom order">
        <div className="grid lg:grid-cols-2 gap-8 items-start">
          <div className="rounded-2xl border border-gray-200 p-6 bg-white shadow-sm">
            <h3 className="font-medium mb-2">How it works</h3>
            <ol className="list-decimal list-inside text-gray-700 space-y-1">
              <li>Tell us what you have in mind.</li>
              <li>We mock up the design for approval.</li>
              <li>Print & press with care, then ship or local pickup.</li>
            </ol>
            <p className="text-sm text-gray-500 mt-3">Turnaround depends on item & quantity. Rush available.</p>
          </div>
          <form className="rounded-2xl border border-gray-200 p-6 bg-white shadow-sm" action="mailto:tabathascustomprints@gmail.com" method="POST" encType="text/plain">
            <div className="grid sm:grid-cols-2 gap-4">
              <label className="flex flex-col gap-1 text-sm">
                <span>Name</span>
                <input required className="px-3 py-2 rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-gray-300" name="name" placeholder="Your name" />
              </label>
              <label className="flex flex-col gap-1 text-sm">
                <span>Email</span>
                <input required type="email" className="px-3 py-2 rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-gray-300" name="email" placeholder="you@example.com" />
              </label>
              <label className="sm:col-span-2 flex flex-col gap-1 text-sm">
                <span>What would you like made?</span>
                <textarea rows={5} className="px-3 py-2 rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-gray-300" name="details" placeholder="Tell us tees, tumblers, sizes, colors, quantities, dates, etc." />
              </label>
              <button type="submit" className="sm:col-span-2 inline-flex justify-center items-center gap-2 px-5 py-3 rounded-2xl bg-gray-900 text-white hover:bg-gray-800">
                <Sparkles className="w-5 h-5" /> Send request
              </button>
              <p className="sm:col-span-2 text-xs text-gray-500">Prefer DMs? Message us on <a className="underline" href="#social">Facebook</a> or <a className="underline" href="#social">Instagram</a>.</p>
            </div>
          </form>
        </div>
      </Section>

      {/* FAQ */}
      <Section id="faq" title="FAQ">
        <div className="grid lg:grid-cols-2 gap-6 text-gray-700">
          <div>
            <h4 className="font-medium">Do you ship?</h4>
            <p className="text-sm text-gray-600">Yes—tracked shipping across the U.S. Local pickup available in Northwest Ohio.</p>
          </div>
          <div>
            <h4 className="font-medium">What shirts do you use?</h4>
            <p className="text-sm text-gray-600">Bella+Canvas 3001, Next Level 6210/3600, and other requested styles.</p>
          </div>
          <div>
            <h4 className="font-medium">Care instructions?</h4>
            <p className="text-sm text-gray-600">Cold wash, inside-out. Hang dry for longest life. No bleach or fabric softener.</p>
          </div>
          <div>
            <h4 className="font-medium">Custom artwork?</h4>
            <p className="text-sm text-gray-600">We can design from scratch or use your file. Vector (SVG/PDF) preferred; high-res PNG okay.</p>
          </div>
        </div>
      </Section>

      {/* Contact + Social */}
      <Section id="contact" title="Contact">
        <div className="grid lg:grid-cols-3 gap-6">
          <div className="rounded-2xl border border-gray-200 p-6 bg-white shadow-sm">
            <div className="flex items-center gap-3"><Phone className="w-5 h-5" /><span>(555) 123-4567</span></div>
            <div className="flex items-center gap-3 mt-2"><Mail className="w-5 h-5" /><a href="mailto:tabathascustomprints@gmail.com" className="underline">tabathascustomprints@gmail.com</a></div>
            <div id="social" className="flex items-center gap-4 mt-4">
              <a aria-label="Instagram" href="#" className="p-2 rounded-xl border border-gray-200 hover:border-gray-300"><Instagram className="w-5 h-5" /></a>
              <a aria-label="Facebook" href="#" className="p-2 rounded-xl border border-gray-200 hover:border-gray-300"><Facebook className="w-5 h-5" /></a>
            </div>
            <p className="text-xs text-gray-500 mt-3">Replace with your real links.</p>
          </div>
          <div className="lg:col-span-2 rounded-2xl border border-gray-200 p-6 bg-white shadow-sm">
            <h4 className="font-medium mb-2">About</h4>
            <p className="text-gray-700">We’re a small shop crafting custom apparel and gifts—one-off pieces and small batches. Dogs welcome in DMs.</p>
          </div>
        </div>
      </Section>

      {/* Footer */}
      <footer className="border-t border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 text-sm text-gray-500 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p>© {new Date().getFullYear()} Tabatha's Custom Prints. All rights reserved.</p>
          <div className="flex items-center gap-4">
            <a href="#faq" className="hover:text-gray-700">FAQ</a>
            <a href="#contact" className="hover:text-gray-700">Contact</a>
            <a href="#" className="hover:text-gray-700">Privacy</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
