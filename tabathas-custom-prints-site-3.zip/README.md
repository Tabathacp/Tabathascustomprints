# Tabatha's Custom Prints — Website

This is a ready-to-deploy React + Tailwind site (Vite).

**Deploy on Netlify**
- Build command: `npm run build`
- Publish directory: `dist`

Paste your Square links into `src/App.jsx` under `checkoutLink`.
